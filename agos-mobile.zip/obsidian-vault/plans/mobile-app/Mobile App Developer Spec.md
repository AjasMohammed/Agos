---
title: Mobile App Developer Spec
tags:
  - mobile
  - api
  - spec
  - plan
date: 2026-06-11
updated: 2026-09-19
status: planned
effort: 8w
priority: high
---

# AgentOS Mobile App — Developer Specification

> Complete handoff specification for building the AgentOS mobile app: a cross-platform client that lets a user manage their entire AgentOS ecosystem — chat with agents, run and monitor tasks, approve risky actions, manage schedules, pipelines, tools, secrets, and system health — from their phone.

This document is self-contained. It is written for a mobile developer who has **not** seen the AgentOS codebase. Everything you need — auth flow, API contracts, screen-by-screen requirements, real-time behavior, error handling, security rules, and milestones — is in this file. The machine-readable API contract lives in `crates/agentos-api/openapi.json` in the repo (OpenAPI 3.1, 135 paths / 177 operations as of 2026-09-19; also served live at `GET /api/v1/openapi.json`, browsable at `/api/v1/docs`); generate your client from it. Where this document and `openapi.json` disagree, **`openapi.json` wins** — file the discrepancy.

> **Reference client:** the React web panel (separate `agentos-panel` repo, sibling of `agos` — ask us for access) consumes this same API (REST + WebSocket, TanStack Query, generated types). When a contract detail is unclear, read how the panel does it before asking.

---

## 1. Product Overview

### 1.1 What AgentOS is

AgentOS is a self-hosted "operating system for AI agents" written in Rust. A user runs the AgentOS **kernel** on their own machine or server. The kernel hosts:

- **Agents** — LLM-backed workers (each bound to a provider/model) that execute tasks using **tools** (file I/O, shell, web search, memory, hardware access, etc.).
- **Tasks** — units of work submitted to an agent ("research X and write a report"). Tasks run autonomously, call tools, can be checkpointed, cancelled, and resumed.
- **Chat sessions** — persistent conversational threads with an agent, with streaming replies.
- **Schedules** — cron-based recurring tasks plus one-shot timers.
- **Pipelines / workflows** — multi-step orchestrations of tasks.
- **Escalations (approvals)** — when an agent wants to do something risky (execute a shell command, write outside its sandbox), the kernel **pauses** and waits for a human to approve or deny. Auto-denies after 5 minutes if nobody answers.
- **Channels** — connections to Discord, Slack, Telegram, etc.
- **Plugins, MCP servers, marketplace** — extension ecosystem.
- **Vault secrets, API keys, audit log, cost tracking, config** — operations surface.

Everything above is exposed over a single authenticated REST + SSE API (`agentos-api`, Axum-based). The mobile app is a **pure client** of that API — no business logic lives on the phone.

### 1.2 Why mobile

The four highest-value mobile jobs, in priority order:

1. **Approvals on the go.** Escalations block agent work until a human decides, and expire (auto-deny) in 5 minutes. A push notification + one-tap approve/deny screen is the killer feature. Nothing else ships before this works.
2. **Chat with agents.** Streaming conversational UI, the dominant phone interaction.
3. **Glanceable monitoring.** "Is my overnight task done? What did it cost? Did anything fail?"
4. **Full ecosystem management.** Everything the web UI and CLI can do — agents, schedules, tools, secrets, config, audit — reachable from the phone in a touch-friendly way. Less-frequent operations can live behind a "Manage" hub rather than top-level tabs.

### 1.3 Deployment model

Single-tenant, self-hosted. Each user runs their own AgentOS server and points the app at it (e.g. `https://agentos.my-house.example:9100`). There is no central AgentOS cloud, no multi-tenant accounts, no app-vendor backend (except the push relay, §9). The app must support **multiple saved servers** with one active at a time (like database clients do).

---

## 2. Tech Stack (required)

| Layer | Choice | Notes |
|---|---|---|
| Framework | **React Native + Expo (managed workflow), TypeScript strict** | Decision already made — see [[Mobile App Plan]]. Do not propose Flutter/native. |
| Navigation | Expo Router or React Navigation (native stack + bottom tabs) | |
| Data fetching | **TanStack Query** | Polling, cache invalidation, optimistic updates, retry — all needed heavily. |
| API client | **Generated from `openapi.json`** (`openapi-typescript` + a thin fetch wrapper, or `orval`) | Hand-written API types are forbidden; the contract drifts otherwise. |
| SSE | `expo/fetch` streaming or `react-native-sse` | Must support POST-initiated SSE (chat stream is a POST). |
| WebSocket | React Native built-in `WebSocket` | Global realtime channel (§8). No library needed. |
| Secure storage | `expo-secure-store` (Keychain / Android Keystore) | API keys live here, never in AsyncStorage. |
| Push | Expo Notifications (Expo Push Service) | §9. |
| State | React Query for server state; Zustand (or similar, small) for app state | No Redux. |
| Charts | `victory-native` or `react-native-svg`-based (small) | Costs + dashboard sparklines only. |
| Builds/distribution | EAS Build + EAS Update; TestFlight + Play internal track first | |

Targets: iOS 16+, Android 10+ (API 29+). Phone-first; must not break on tablets (simple responsive layout, no tablet-specific design required in v1). Dark and light mode both required — developer/ops audience skews dark mode.

---

## 3. Connectivity, API Conventions

### 3.1 Base URL and server profiles

- All endpoints are under `{baseUrl}/api/v1/...`.
- The app stores a list of **server profiles**: `{ name, baseUrl, apiKey }`. One is active. Switching profiles flushes the query cache.
- `GET /api/v1/health` is **unauthenticated** — use it to validate a server URL during onboarding and as a connectivity probe.
- Support `http://` only for LAN/private addresses with an explicit "insecure connection" warning; default expectation is HTTPS (user fronts the server with a reverse proxy or tunnel — Tailscale/Cloudflare Tunnel are the common setups; nothing special needed in-app, they look like normal HTTPS).

### 3.2 Authentication

The server uses bearer keys with an operator-login bootstrap:

1. **Login:** `POST /api/v1/auth/login` with `{ "credential": "<operator token>" }` (the deployment's operator token, configured server-side). Public but heavily rate-limited. Response (in the standard envelope): `{ api_key: "agos_…", key_id, name, scopes: ["*:rw"], expires_at }`. The raw key is shown **once** — persist it immediately to secure storage.
2. **Every request:** header `Authorization: Bearer agos_<key>`.
3. **Whoami:** `GET /api/v1/auth/me` → identity + scopes of the presented key. Call on app start to validate the stored key.
4. **Refresh:** `POST /api/v1/auth/refresh` mints a fresh key with the same scopes/new TTL and **revokes the old one**. Keys live 24 h. Gated by server config — the route can be absent (404) when disabled.

App behavior required:

- **Proactive refresh:** track `expires_at`; refresh when < 6 h remain and the app is foregrounded. Persist the new key atomically *before* discarding the old one (write-then-swap; a refresh revokes the old key, so a failed write = locked out).
- **401 handling:** on any 401, attempt one refresh; if refresh fails or is disabled, route to the login screen for that server profile with a clear "session expired" message. Never silently loop.
- **Alternative auth:** advanced users may paste a long-lived API key (minted via `POST /api/v1/keys` elsewhere) instead of logging in. The onboarding screen must offer both: "Login with operator token" and "Paste API key".
- The credential/operator token is **never stored** — only the minted `agos_` key.

### 3.3 Response envelope and errors

Every JSON response is wrapped:

```json
{ "data": <payload>, "meta": { ... } }          // success
{ "error": { "code": "...", "message": "..." } } // failure (non-2xx)
```

List endpoints use a list envelope with pagination metadata in `meta` (`limit`/`offset` style query params — check `openapi.json` per endpoint; e.g. tasks, chat sessions, files, audit support filtering/paging).

Error handling rules:

- Map `error.message` into user-facing toasts/banners verbatim (messages are written to be human-readable).
- 403 → "Your key doesn't have permission for this" (scoped keys exist; don't treat as a bug).
- 429 → respect and back off; show "Rate limited, retrying…".
- 503 on `/auth/login` means login is disabled server-side → guide user to the API-key path.
- Network failure ≠ server error: distinguish "can't reach server" (offline banner, queue refetch) from API errors.

### 3.4 Offline policy

Online-only in v1 (decision in [[Mobile App Plan]]). Required:

- React Query cache makes previously loaded screens readable while offline (stale data + a persistent "offline — showing cached data" banner with last-sync time).
- All mutations are disabled (buttons in disabled state with a tooltip/toast) while offline. No mutation queueing.

---

## 4. Information Architecture

Bottom tab bar (5 tabs) + a "Manage" hub for everything else:

```
┌──────────────────────────────────────────────────────┐
│ Tabs:                                                │
│  ● Home       — dashboard, health, recent activity   │
│  ● Chat       — sessions list → streaming thread     │
│  ● Tasks      — task list → detail/trace/resume      │
│  ● Approvals  — escalations + notifications inbox    │
│  ● Manage     — hub grid for everything else         │
│                                                      │
│ Manage hub →                                         │
│   Agents · Schedules · Pipelines · Workflows         │
│   Tools · Plugins · MCP Servers · Marketplace        │
│   Channels · Connectors · Scratchpad · Files         │
│   Secrets · API Keys · Roles · Webhooks              │
│   Costs · Audit Log · Logs · Preference Proposals    │
│   Config · System Health · App Settings              │
└──────────────────────────────────────────────────────┘
```

- The **Approvals tab badge** shows pending escalation count + unread notification count — this is the most important number in the app.
- Global elements: pull-to-refresh on every list; a thin connection-status indicator (green dot when `/health` ok and event stream connected); universal empty states ("No tasks yet — run one from the + button"); skeleton loaders, never blank screens.
- A global **"+" action** (FAB or nav-bar button) on Home/Tasks/Chat: New chat · Run task · New schedule.

---

## 5. Screen Specifications

For each screen: purpose, endpoints, UI, and behaviors. All paths are relative to `/api/v1`.

### 5.0 Onboarding & server connect

**Screens:** Welcome → Add Server → Authenticate.

1. Add Server: name + base URL fields. On submit, probe `GET /health`. Show server version/status on success; specific errors on failure (DNS, TLS, timeout, non-AgentOS response).
2. Authenticate: segmented choice — **Operator token** (calls `POST /auth/login`) or **API key** (paste `agos_…`, validate via `GET /auth/me`).
3. On success: store profile + key in SecureStore, register device for push (§9), land on Home.
4. QR-code connect (stretch, v1.1): scan a QR encoding `{baseUrl, token}` displayed by the server's web UI/CLI.

Settings must allow: multiple profiles, switch active, edit, delete (deleting wipes that profile's key from SecureStore).

### 5.1 Home (Dashboard)

**Purpose:** 10-second answer to "is everything okay and what happened recently?"

**Endpoints:** `GET /dashboard` (composite: agents, task counts, tool count, uptime, recent audit, background tasks), `GET /status`, `GET /escalations` (pending count), `GET /notifications/unread`, `GET /costs/summary`, `GET /resources`.

**UI:**
- Header: server name, kernel uptime, connection dot.
- **Attention strip** (only when non-empty, colored): "2 approvals waiting" → Approvals tab; "1 task failed" → filtered task list; "doctor found issues" → System Health.
- Stat cards: active agents, running/queued/completed/failed task counts (tap → filtered lists), today's cost.
- Recent activity feed: last ~15 audit entries (`/dashboard` includes them) rendered as friendly sentences with icons ("agent *researcher* completed task • 2m ago").
- Refresh: poll every 30 s while foregrounded + realtime-driven invalidation (§8) + pull-to-refresh.

### 5.2 Chat

**Purpose:** full conversational client with streaming.

**Endpoints:**
- `GET /chat/sessions` (list, most-recent first), `POST /chat/sessions` (create — `{ agent_name, title?, first_message? }`), `GET /chat/sessions/{id}` (session + message timeline), `PATCH` (rename), `DELETE` (delete), `POST /chat/sessions/{id}/fork`, `GET /chat/sessions/{id}/export?format=json|markdown`.
- `GET /chat/sessions/{id}/messages`, `POST /chat/sessions/{id}/messages` (non-streaming fallback). Send body for both send endpoints: `{ text, file_ids? }` — `file_ids` are ids from `POST /files` (§5.12), so the composer needs an attach button (document picker / photo / camera → upload → attach).
- **`POST /chat/sessions/{id}/messages/stream`** — SSE. Event types: `thinking`, `chunk` (assistant text delta), `tool_start`, `tool_result`, `done`, `error`. Both turns are persisted server-side regardless of client disconnect.

**UI:**
- Sessions list: title (or first-message preview), agent name, relative time, swipe actions (rename/delete). New-chat sheet picks an agent (`GET /agents`).
- Thread: standard bubbles. Streaming behaviors that matter:
  - `thinking` events → collapsed "Thinking…" shimmer row (expandable to view, if payload carries text).
  - `tool_start`/`tool_result` → inline collapsible chips in the transcript: "🔧 web-search — *running…*" → "✓ web-search (1.2 s)", expandable to show input/output (pretty-printed JSON, monospace, copy button).
  - `chunk` → append to the live assistant bubble; render markdown progressively (code blocks with copy, tables horizontally scrollable).
  - `done` → finalize; `error` → red inline banner in-thread with retry.
- **Disconnect recovery:** if the SSE drops mid-reply (backgrounding, network blip), do not retry the POST (it would send the message again). Instead refetch `GET /chat/sessions/{id}` — the completed turn is persisted server-side — and reconcile the thread.
- Composer: multiline, attach button, send button, disabled while a reply streams. **Stop button:** shown while streaming when the global WebSocket (§8) is connected — sends a `chat.cancel` frame `{ type: "chat.cancel", session_id }`; server answers `chat.cancelled`. Hide it when the socket is down (there is no REST cancel for chat).
- **Inline approval card:** when a tool call in the turn needs approval, the turn parks until resolved. Surface the pending escalation (match on `task_id`, §5.4) as an inline approve/deny card in the thread rather than forcing a tab switch.
- Overflow menu: rename, fork ("duplicate conversation"), export/share (markdown via OS share sheet), delete (confirm).

### 5.3 Tasks

**Purpose:** submit, monitor, inspect, cancel, resume.

**Endpoints:** `GET /tasks` (filterable: status, agent, paging), `GET /tasks/{id}`, `GET /tasks/{id}/trace`, `POST /tasks/run` (`{ prompt, agent_name?, autonomous? }`), `POST /tasks/{id}/cancel`, `GET /tasks/{id}/checkpoints`, `POST /tasks/{id}/resume`.

**UI:**
- List: status filter chips (All · Running · Queued · Completed · Failed), each row = status icon/color, prompt excerpt (2 lines), agent, relative time, duration. Running rows show an animated indicator. Poll every 5 s while any task is running, else 30 s; SSE invalidation too.
- **Run Task sheet** (from "+"): prompt (multiline), agent picker, "autonomous" toggle with a one-line explanation ("don't pause for approvals on lower-risk actions"). Submit → optimistic row appears.
- **Detail:** full prompt, status timeline (created → started → finished), result/output (markdown), error block when failed, cost if available, agent link.
  - **Trace view** (`/tasks/{id}/trace`): the differentiator. Vertical timeline of execution steps — each tool call as a card (name, duration, success/fail, expandable input/output JSON). Make this *good*: it's how users debug their agents from the couch.
  - Actions: Cancel (running; confirm dialog → `POST /tasks/{id}/cancel`), **Resume** (visible only when `GET /tasks/{id}/checkpoints` returns one — show "checkpoint from {time}, {n} tool calls" and a Resume button → `POST /tasks/{id}/resume`).
- Failed tasks with a checkpoint should surface a "Resume from checkpoint" CTA right in the list row.

### 5.4 Approvals (Escalations) — flagship

**Purpose:** approve/deny agent actions in seconds, from a push notification.

**Endpoints:** `GET /escalations` (pending by default; `?pending=false` for history), `GET /escalations/{id}`, `POST /escalations/{id}/resolve` with `{ "decision": "approve" | "deny", "note"?: string, "remember"?: boolean }` → `{ status, escalation_id, task_id, task_resumed, policy_id?, remember_note? }`. Standing rules: `GET /approval-policies`, `POST /approval-policies` (`{ tool_name, agent_id?, path_glob?, expires_at? }`), `DELETE /approval-policies/{id}`.

**Domain facts that shape the UX:**
- Escalations **auto-deny at `expires_at`** (currently 5 minutes after creation — drive the countdown from the field, never a hardcoded 300 s). Every pending card must show a **live countdown** (mm:ss, turning red < 60 s).
- Escalation shape (`ApiEscalation`): `id` (integer), `task_id`, `agent_id`, `reason`, `context_summary` (human-readable headline, secrets already redacted server-side), `decision_point`, `options` (e.g. `["approve","deny"]` — render buttons from this), `urgency`, `blocking`, `created_at`, `expires_at`, `resolved`, `resolution`, and a free-form **`metadata`** object.
- For tool approvals `metadata` is `{ kind, tool_name, risk_class, path, scoped_action, input }`. `risk_class` is **PascalCase** here (`ReadonlyScoped`, `ReadonlyExternal`, `WriteScoped`, `ExecCapable`, `ControlPlane`, `Interactive`) — unlike tool manifests (§5.9), which use snake_case. `input` is the redacted tool payload as structured JSON: this is the input preview. Every metadata key is optional — other escalation kinds exist; fall back to `context_summary` + `decision_point` when `tool_name` is absent.
- **"Always approve" (`remember: true`)** mints a standing approval policy for that tool (+ `path` when present); the response carries `policy_id`. When `metadata.scoped_action` is set the server **refuses** to mint one (the approval was for a single action) and explains why in `remember_note` — show that note, don't treat it as an error.

**UI:**
- Tab has three segments: **Pending**, **History** (approved/denied/expired with who/when/note) and **Rules** — the standing approval policies list (tool, agent or "all agents", path glob, source, granted by/at, expiry) with swipe-to-revoke (confirm). A rule silently auto-approves future calls, so revoking must be easy to find.
- Pending card: agent avatar/name, tool name, **risk-class badge** (color-coded: greens for readonly, orange for write, red for exec/control-plane), the input preview (`metadata.input`, via the shared JSON viewer) in a monospace block (this is *what the agent wants to do* — never truncate the command without an expand affordance), countdown, and two large buttons: **Deny** (left, neutral) / **Approve** (right, prominent). Optional note field behind "add note". An **"Always approve this tool"** checkbox (→ `remember: true`), off by default, hidden for `ExecCapable`/`ControlPlane` unless the user expands "advanced", and disabled with an explanation when `metadata.scoped_action` is set.
- Approve for `ExecCapable`/`ControlPlane` risk requires a second step: slide-to-confirm or confirm dialog. Deny is always one tap.
- **Biometric gate (required, simple):** if the device has Face ID/Touch ID/class 3 biometrics enrolled, require local biometric auth before submitting an *approve* (not deny). `expo-local-authentication`.
- Resolving an already-expired/already-resolved escalation returns an API error — render it gracefully ("this expired 2 m ago") and refresh the list.
- Poll every 10 s while the tab is visible; rely on push + SSE otherwise.
- **Push → deep link** directly to the escalation detail with approve/deny above the fold (§9).

### 5.5 Notifications inbox

**Endpoints:** `GET /notifications` (filterable), `GET /notifications/unread` (count), `GET /notifications/{id}`, `POST /notifications/{id}/respond`, `POST /notifications/{id}/read`, `POST /notifications/read-all`, `DELETE /notifications/{id}` (dismiss), `DELETE /notifications/read` (clear read), `DELETE /notifications` (clear all — live questions survive).

**UI:** second segment inside the Approvals tab (or sub-screen). Standard inbox: unread dot (opening marks read), swipe-to-dismiss, "mark all read" / "clear read" / "clear all" in overflow. Notifications that accept a response (the agent asked the user a question via `notify-user`) render an inline reply field posting to `/respond`.

### 5.6 Agents

**Endpoints:** `GET /agents`, `GET /agents/{name}`, `POST /agents` (connect new), `DELETE /agents/{name}`, `POST /agents/{name}/settings`, `GET /agents/{name}/identity`, `POST /agents/{name}/permissions` + `/permissions/revoke`, `GET|PUT|DELETE /agents/{name}/scratchpad[/{page}]`, `GET /agents/{id}/memory/{tier}?q=&limit=` (browse/search a memory tier — `episodic` / `semantic` / `procedural`), `GET /agents/{id}/inbox?limit=` (agent-to-agent message history, oldest first), `GET /costs/agents/{name}`, `GET /providers` (provider/model catalog for the connect form).

**UI:**
- List: agent cards — name, model/provider, status, today's cost, running-task count.
- Detail (segmented):
  - **Overview:** model, provider, status, uptime, cost summary, recent tasks (filtered `/tasks`), "Chat with this agent" button.
  - **Permissions:** granted permission list; grant via a form (permission string + scope), revoke via swipe. MCP access is granted **per server** as `mcp:<server>/:x` (not per tool) — offer a picker of attached servers from `GET /mcp` instead of free text for these. Destructive-styled; this is a security surface — show exactly what's being granted, confirm dialogs both ways.
  - **Scratchpad:** the agent's working-memory pages — list, markdown viewer, edit (plain-text editor is fine), delete. Render `[[wikilinks]]` as tappable links to sibling pages.
  - **Memory:** tier picker + search box over `/memory/{tier}`; read-only list → detail.
  - **Inbox:** read-only agent-to-agent message timeline.
  - **Settings:** form per `UpdateAgentSettingsRequest` → `POST settings`: `description`, `system_prompt`, `thinking_level` (off/low/medium/high/max), `working_set_size`, `avatar` (image **data URL**, server cap 64 KB — downscale/compress on device before upload; use the avatar everywhere an agent appears).
  - **Identity:** public key fingerprint, copyable.
- Connect agent (advanced, from overflow): form per `ConnectAgentRequest` schema. Disconnect = destructive confirm.

### 5.7 Schedules

**Endpoints:** `GET /schedules` (returns cron schedules **and** agent-created one-shot jobs/timers — discriminated by `kind`), `POST /schedules` (`{ name, agent_name, cron, prompt, delivery_mode? }`), `POST /schedules/preview` (`{ cron }` → upcoming fire times; pure, no side effects), `POST /schedules/{id}/pause` / `/resume`, `DELETE /schedules/{id}`, `GET /schedules/{id}/runs`.

**UI:**
- List grouped by kind (Recurring / One-shot / Timers): name, agent, human-readable cron ("every day at 9:00" — use `cronstrue`), next fire time, paused state, last-run status dot.
- **Create:** name, agent picker, prompt, cron builder — a friendly preset picker (hourly/daily/weekly/custom) that always shows the raw cron string *and* live-calls `/schedules/preview` to display "next 3 runs: …" before saving. This preview is mandatory UX.
- Detail: definition + **Runs** list (`/runs`): per-fire history with status, time, link to the spawned task when available.
- Pause/resume = toggle with optimistic update; delete = confirm.

### 5.8 Pipelines & Workflows

**Endpoints — pipelines:** `GET /pipelines`, `GET /pipelines/{name}`, `POST /pipelines` (save), `POST /pipelines/import` (raw YAML), `GET /pipelines/{name}/export` (YAML), `DELETE`, `POST /pipelines/{name}/run`, `GET /pipelines/runs/{run_id}/events` (run snapshot).
**Endpoints — workflows:** `GET /workflows`, `POST /workflows`, `GET|PUT|DELETE /workflows/{id}`.

**v1 scope (important):** mobile is a **viewer + runner**, not a visual builder. Building complex pipelines on a phone is poor UX; the web UI owns authoring.

**UI:**
- Pipelines list → detail: render the step graph **read-only** as a vertical step list (step name, agent/tool, dependencies as "after: X"). A real DAG canvas is out of scope.
- **Run** button → `POST /run` (with an input form if the definition declares inputs) → live run screen polling `GET /pipelines/runs/{run_id}/events` every 2–3 s: per-step status checklist (pending/running ✓/✗), durations, expandable step output, overall progress bar.
- Import: paste-YAML screen (and "import from clipboard"); Export: share sheet with the YAML.
- Workflows: same list/detail/run-style treatment per the `SaveWorkflowRequest` schema; edits limited to metadata (rename) in v1.

### 5.9 Tools, Plugins, MCP, Marketplace

**Endpoints:** `GET /tools`, `GET /tools/{name}`, `POST /tools` (install from manifest path — **hide on mobile**, server-path semantics don't fit), `DELETE /tools/{name}`; `GET /plugins`, `GET /plugins/{id}`, `POST /plugins`, `PUT|DELETE /plugins/{id}`, `POST /plugins/{id}/enable|disable`, `POST /plugins/discover`; `GET /mcp`, `POST /mcp` (attach), `PUT /mcp/{name}` (edit), `POST /mcp/{name}/detach`, `GET /mcp/catalog`, `GET /mcp/catalog/{id}`, `POST /mcp/catalog/{id}/install` (`InstallMcpRequest`); `GET /skills`, `GET /skills/{name}`; `GET /marketplace?q=&type=`, `GET /marketplace/{name}`, `POST /marketplace/{name}/reviews`.

**UI:**
- **Tools:** searchable list (name, description, **trust-tier badge**: Core/Verified/Community/Blocked, **risk-class badge**). Detail: full description, permissions required, intent schema (collapsible JSON). Remove = destructive confirm (Core tools: hide remove).
- **Plugins:** list with status (Discovered/Active/Disabled/Blocked) and enable/disable toggles; "Rescan" button → `/plugins/discover`.
- **MCP servers:** list (live + persisted) with tool counts and status; detach with confirm. **Catalog** sub-screen: browse `GET /mcp/catalog`, entry detail, **Install** → `InstallMcpRequest` `{ allow_community?, no_auth?, runtime_binary? }` (all optional). `allow_community` opts into a Community-trust-tier entry — never default it on; show the entry's trust tier and make the user tick it explicitly. Leave `runtime_binary` out on mobile (server-path semantics). Servers needing credentials are configured via Secrets (§5.13) / server-side, not in this form. Manual attach/edit (`POST /mcp`, `PUT /mcp/{name}`) is an advanced form — ship after catalog install. Installing a server grants nothing: remind the user to grant `mcp:<server>/:x` to an agent (§5.6).
- **Plugins** create/edit/delete (`POST`, `PUT`, `DELETE`): manifest-path semantics like tool install — **hide on mobile** in v1; keep enable/disable/rescan.
- **Skills:** read-only list + detail (name, description, prompt body as markdown).
- **Marketplace:** search with type filter; item detail; submit review (rating + text). MCP entries install via the catalog flow above; for other item types show the CLI command to copy.

### 5.10 Channels & Connectors

**Endpoints — channels:** `GET /channels`, `POST /channels`, `GET|PUT /channels/{id}`, `PUT /channels/{id}/agent` (rebind to another agent), `POST /channels/{id}/test`, `POST /channels/{id}/disconnect`; pairing: `GET /channels/pairings` (approved + pending), `POST /channels/pairings/{code}/approve`, `POST /channels/{id}/pairings/{sender_id}/approve`, `DELETE /channels/{id}/pairings/{sender_id}`.
**Endpoints — connectors:** `GET /connectors`, `POST /connectors`, `GET|PUT|DELETE /connectors/{id}`, `POST /connectors/{id}/credential`, `POST /connectors/{id}/oauth/start` (+ server-side `GET …/oauth/callback`), `POST /connectors/{id}/disconnect`.

**UI:**
- Channels list with platform icon (Discord/Slack/Telegram/…), bound agent, health status. Detail: **Test** button, **change agent** picker, disconnect (destructive confirm).
- **Pairing requests — build this well:** someone DMs the bot, gets a 6-char code (10-min expiry), and is blocked until the operator approves. That is a phone-shaped job. Pending pairings list with Approve (by code or by sender) / Revoke; include pending-pairing count in the Home attention strip.
- Channel create/edit (`POST`/`PUT /channels`) involves pasting bot tokens — supported by the API, **v1.1 on mobile**; if built, token fields follow §10 secret rules.
- Connectors: list, detail, disconnect, delete. OAuth connect = `POST …/oauth/start` → open the returned `authorize_url` in the system browser (`expo-web-browser`); the callback lands on the server, so just refetch the connector on return. Raw credential entry (`/credential`) follows §10 secret rules.

### 5.11 Memory & Scratchpad (global)

**Endpoints:** `GET /scratchpad`, `GET|PUT|DELETE /scratchpad/{page}`.

**UI:** like agent scratchpads (§5.6) but global: page list with search, markdown render, tappable `[[wikilinks]]`, edit, delete. Nice-to-have: backlinks section if the payload provides them.

### 5.12 Files

**Endpoints:** `GET /files?tag=&q=&scope=` (filter by tag, search, scope), `POST /files` (multipart upload), `GET /files/{id}`, `GET /files/{id}/download`, `DELETE /files/{id}`.

**UI:** file list (name, size, type icon, date), upload via document picker / photo library / camera, download → OS share sheet/preview (Quick Look / intent), delete with confirm. Show upload progress. Search box + tag filter chips. Uploaded file ids are what chat `file_ids` reference (§5.2).

### 5.13 Secrets, API Keys, Roles, Webhooks (security surfaces)

**Endpoints:** `GET /secrets` (metadata only — values are never returned), `POST /secrets` (set/update), `DELETE /secrets/{name}`; `GET /keys`, `POST /keys` (raw key returned **once**), `DELETE /keys/{id}` (revoke); `GET /roles`, `POST /roles`, `GET|DELETE /roles/{name}`; `GET /webhooks`, `POST /webhooks` (secret returned **once**), `POST /webhooks/{id}/rotate` (returned once), `DELETE /webhooks/{id}`; `GET /workspace-grants`, `POST /workspace-grants` (`{ path, agent_name?, mode? }` — `path` must be absolute, `~` is not expanded; `mode` defaults to `rw`), `DELETE /workspace-grants?path=…&agent_name=…`.

**UI rules:**
- Secrets: list shows name + created/rotated date only. Set/update form's value field uses `secureTextEntry`, is excluded from screenshots where the platform allows, and is cleared on blur/navigation. Never log it.
- API keys: list with name, scopes, expiry, last-used; revoke with confirm. Mint form: name + scopes; the **show-once** raw key gets a dedicated "copy now, you won't see this again" modal with copy button.
- Same show-once modal pattern for webhook secrets and rotation.
- Roles: list/detail of permission sets; create form; delete confirm.
- **Workspace grants** (host folders agents may touch): list — path, mode, agent or "all agents", source, granted by/at. Revoke with confirm (note: revoke is keyed by `path` + `agent_name` query params, not by id). Granting types a server-side absolute path — allowed but behind an "advanced" affordance with a confirm that echoes the exact path and mode; the server rejects invalid paths (400), surface its message.
- Mark which key the app itself is using ("this device") and prevent revoking it without an extra warning.

### 5.14 Costs

**Endpoints:** `GET /costs/summary`, `GET /costs/agents/{name}`.

**UI:** total spend cards (today / 7d / 30d as data allows), per-agent breakdown list sorted by spend with sparkline, tap → agent cost detail (per-model/per-task breakdown as the payload provides). Currency formatting; if budgets appear in the payload (`CostBudget`), render budget progress bars.

### 5.15 Audit Log & Logs

**Endpoints:** `GET /audit/logs` (filters: agent, event type, time range, paging), `GET /audit/logs/{trace_id}`, `GET /audit/verify` (integrity check); `GET /logs` (level/since filters).

**UI:**
- Audit: filterable, infinitely-scrolling list — event-type icon, agent, summary, time. Detail screen = full structured payload (pretty JSON, copyable, share). A "Verify integrity" action runs `/audit/verify` and shows a pass/fail banner.
- Logs: simple tail view, level filter chips (error/warn/info), monospace, newest-first, "load more".

### 5.16 Preference Proposals

**Endpoints:** `GET /prefs/proposals?status=`, `POST /prefs/proposals/{id}/accept|reject`, `GET /prefs/stats`.

**Context:** after tasks complete, the system proposes user-preference adaptations ("user prefers concise answers"). Humans accept/reject.

**UI:** Tinder-simple review list — proposal text, source task link, Accept/Reject buttons, stats header (pending/accepted/rejected counts). Low effort, high polish-per-line.

### 5.17 Config

**Endpoints:** `GET /config` (full tree, secrets redacted), `GET /config/{key}` (dotted key), `PUT /config/{key}` (gated server-side by `[api] config_writable` → 403 when disabled; the kernel hot-reloads on write).

**UI:** collapsible tree browser of sections → key/value rows. Editing: tap a leaf → typed editor (bool switch, number pad, string field) with the dotted key shown. If the first PUT returns 403, flip the whole screen to read-only mode with an explanatory banner ("config writes are disabled on this server"). Show redacted values as `••••` (not editable). This is an expert screen — prioritize correctness over beauty.

### 5.18 System Health

**Endpoints:** `GET /doctor` (read-only diagnostic checks), `POST /doctor/fix` (auto-repair + re-run), `GET /resources` (host memory/disk + live resource locks), `GET /hal` (hardware device inventory), `GET /status`.

**UI:** checklist of doctor checks (✓/✗/⚠ + message), "Attempt auto-fix" button (confirm first) showing the updated report; resource gauges (memory/disk); HAL device list (name, type, status) read-only; kernel version/uptime. This screen is also the natural home for the "something's wrong" deep link from Home.

### 5.19 Events (power-user, low priority)

**Endpoints:** `GET /events/subscriptions`, `POST /events/subscriptions`, `DELETE /events/subscriptions/{id}`, `POST .../enable|disable`, `POST /events/emit`.

**UI:** plain CRUD list + create form, in Manage. Build last; ship in v1 only if time allows. (`/events/stream` is only the app's fallback realtime path — §8.)

### 5.20 App Settings

Server profiles (§5.0) · push notification preferences (master toggle + per-category: approvals/task-completion/failures; approval pushes default ON and warn loudly when turned off) · biometric-on-approve toggle (default on when available) · appearance (system/dark/light) · diagnostics (app version, server version from `/health`, connection test button) · sign out (revoke own key via `DELETE /keys/{id}` best-effort, wipe SecureStore entry).

---

## 6. Multi-agent Conversations (v1.1, behind a flag)

`GET|POST /agent-chats`, `GET /agent-chats/{id}`, `POST /agent-chats/{id}/stop`, `POST /agent-chats/{id}/messages` (`{ content }` — operator interjects; a running conversation answers on its next turn, a finished one resumes for one round), `POST /agent-chats/{id}/continue` (`{ turns }` — resume a finished conversation in place for N more turns) — orchestrated multi-agent conversations with a turn timeline. Turns stream live on WebSocket channel `agent-chat:<id>` (scope `chat:r`, §8): typing indicator + streamed text; poll `GET /agent-chats/{id}` as fallback. Build: create, watch, stop, operator message composer (operator rows render as `@user`), Continue button on finished conversations. Do not let this delay v1.

---

## 7. UX & Design Principles

1. **Glanceable first.** Every screen answers its core question without scrolling: status colors (green/amber/red used consistently for success/running/failed), counts in tab badges, relative timestamps everywhere ("2 m ago", absolute on long-press).
2. **Risky things look risky.** Risk-class badges, destructive buttons styled destructively, confirms on irreversible actions (delete, revoke, disconnect, approve-exec), biometrics on approval. Never make Deny harder than Approve.
3. **JSON is a first-class citizen.** Tool inputs/outputs, audit payloads, traces, schemas: collapsible, syntax-highlighted (a single monospace style is fine), copyable pretty-printed JSON viewer used consistently across the app. Build it once as a shared component.
4. **Markdown everywhere agents speak.** Chat replies, task results, scratchpad pages — one shared markdown renderer (code blocks w/ copy, tables, links).
5. **Never block on the network.** Optimistic updates for toggles (pause/resume, enable/disable) with rollback on error; skeletons not spinners; stale-while-revalidate via React Query defaults.
6. **Forgiving forms.** Drafts of chat composer and run-task prompt survive navigation/app-kill (persist to storage, clear on send).
7. **Accessibility:** dynamic type support, 44 pt touch targets, VoiceOver/TalkBack labels on icon buttons, WCAG AA contrast in both themes.

---

## 8. Real-time Strategy (WebSocket + SSE)

Three realtime consumers:

1. **Chat streaming** (§5.2): `POST /chat/sessions/{id}/messages/stream`. Per-message lifecycle; closed at `done`.
2. **Global realtime socket (primary):** `GET /api/v1/ws?ticket=<ticket>`. Mint the ticket with `POST /api/v1/ws/ticket` (Bearer auth) → `{ ticket, expires_in }`; it is **single-use and short-lived**, so mint a fresh one for every connect/reconnect. Never put the `agos_` key in the URL (a legacy `?token=` form exists — do not use it; URLs land in proxy logs).
   - All frames are JSON with a `type` discriminator. Client → server: `subscribe { channel, filter? }`, `unsubscribe { subscription_id }`, `chat.send { session_id, message, agent_name? }`, `chat.cancel { session_id }`, `task.cancel { task_id }`, `notification.respond { id, text }`, `ping`. Server → client: `subscribed { channel, subscription_id }`, `unsubscribed`, `event { channel, event, data }`, `chat.chunk { session_id, delta }`, `chat.done { session_id, tool_calls }`, `chat.cancelled { session_id }`, `error { code, message }`, `pong`.
   - Channels are scope-checked against the ticket's key (e.g. `agent-chat:<id>` needs `chat:r`). The machine-readable frame list + event catalog (11 categories: task lifecycle, agent lifecycle, chat, security, schedule, system health, …) is `crates/agentos-api/events.json` — generate the TS types from it, same no-hand-rolled-types rule as REST.
   - While the app is **foregrounded**, hold one socket and use `event` frames to invalidate React Query caches (tasks, escalations, notifications, dashboard) so lists update without aggressive polling. Map event categories → query-key invalidations; unknown channels/events/frame types are ignored silently (forward compatibility). Send `ping` every ~30 s; treat a missed `pong` as a dead socket.
   - Use the socket for **`chat.cancel`** (§5.2). Keep chat *sending* on the SSE POST (1) — it carries the richer `thinking`/`tool_start`/`tool_result` events the WS chat frames don't.
3. **SSE event stream (fallback):** `GET /events/stream?channel=<name>` (Bearer header; may emit a `lagged` event when the client falls behind → refetch everything). Use only if the WebSocket can't be established through the user's proxy.

Reconnect policy (all): exponential backoff 1 s → 30 s with jitter; reconnect on app foreground and network-regain (NetInfo); show the connection dot state. On background: close the global stream (iOS will kill it anyway); rely on push. **Polling is the fallback, not the enemy** — every list screen keeps a modest poll interval (§5 per-screen) so the app works even if SSE proves flaky through some proxy; SSE just makes it feel instant.

---

## 9. Backend Dependencies (not yet built — coordinate, don't block)

Status re-verified 2026-09-19: none of these exist yet (no `/devices` route, no push code in the workspace). The backend team (us) owes the app these. Until they land, the app must function with the documented fallbacks.

| # | Dependency | Contract (proposed) | Fallback until ready |
|---|---|---|---|
| 1 | **Device registration for push** | `POST /api/v1/devices` `{ platform: "ios"|"android", expo_push_token, device_name }`; `DELETE /api/v1/devices/{id}`; `GET /api/v1/devices` | App polls `/escalations` every 10 s foregrounded; no background alerts |
| 2 | **Push relay** (kernel → Expo Push Service) for: escalation created (high priority), task completed/failed, notification created | Push payload carries `{ type, id }` for deep linking: `agentos://escalations/{id}`, `agentos://tasks/{id}`, `agentos://notifications/{id}` | — |
| 3 | REST chat cancel (today WS-only: `chat.cancel`) | `POST /chat/sessions/{id}/cancel` TBD | Stop button only while socket is up (§5.2) |
| 4 | Longer-lived refresh window or refresh-token flow (current keys: 24 h, refresh rotates) | TBD | Proactive refresh per §3.2; worst case re-login every 24 h |

Implement deep-link routes (`agentos://…` + universal links) from day one so push integration is a payload-mapping exercise.

The Expo push token flow on the app side (permissions prompt timing — ask **after** first login, with a rationale screen, not at cold start) should be built and tested against a mock as part of Milestone 2.

---

## 10. Security Requirements (non-negotiable)

1. API keys only in Keychain/Keystore (`expo-secure-store`); never AsyncStorage, never logged, never in crash reports (scrub breadcrumbs).
2. Operator credential is used transiently for login and never persisted.
3. No third-party analytics/telemetry SDKs in v1. Crash reporting (Sentry) allowed only with scrubbing of URLs, headers, and bodies.
4. Certificate validation always on; no `NSAllowsArbitraryLoads` blanket exceptions (scoped LAN/http exception only behind the explicit insecure-server opt-in).
5. Biometric gate on approvals (§5.4); app does not implement its own PIN.
6. Secret values: `secureTextEntry`, cleared from state on navigation, excluded from React Query cache (mutations only, never cached).
7. Show-once values (minted keys, webhook secrets) are never persisted by the app — copy-to-clipboard only, with a clipboard-cleared-after-60 s nicety where the platform supports it.
8. Deep links validate the target exists (fetch by id) before rendering an actionable approve/deny UI; never auto-approve from a link parameter.

---

## 11. Milestones & Acceptance

Suggested order (each milestone = demoable build on TestFlight/internal track):

| M | Scope | Acceptance gate |
|---|---|---|
| **M1 — Foundation** (≈2 w) | Project scaffold, OpenAPI codegen pipeline, server profiles + onboarding + login/refresh, Home dashboard, navigation shell, shared components (JSON viewer, markdown, list/empty/skeleton patterns) | Connect to a real AgentOS server, login both ways, dashboard live-updates, key refresh survives app restart |
| **M2 — The core loop** (≈2 w) | Approvals (full §5.4 incl. biometrics + countdown + always-approve + Rules segment), Notifications, Tasks (list/run/detail/trace/cancel/resume), deep-link routes, push-token registration against mock | Approve a real escalation from the phone in < 10 s from a cold start; resume a checkpointed task |
| **M3 — Chat** (≈1.5 w) | Sessions CRUD, SSE streaming thread with thinking/tool chips, disconnect reconciliation, export/fork | Stream a long agent reply with tool calls over flaky network (airplane-mode toggle test) without duplicated messages |
| **M4 — Manage hub** (≈2 w) | Agents (incl. permissions + scratchpad), Schedules (incl. cron preview), Costs, Audit/Logs, Secrets/Keys/Roles/Webhooks, Tools/Plugins/MCP (incl. catalog install)/Skills/Marketplace, Channels (incl. pairing approvals)/Connectors, Workspace grants, Files, Scratchpad, Prefs proposals, Config, System Health | Every ecosystem object is viewable, and every documented mutation works, from the phone |
| **M5 — Polish & release** (≈1 w) | Pipelines/workflows viewer+runner, global WebSocket invalidation (SSE fallback), offline banners, dark mode audit, accessibility pass, EAS release pipeline, store assets | Checklist §12 green; TestFlight external + Play internal track live |

### 12. Definition of done (release checklist)

- [ ] All §5 screens implemented per spec; §6 and §5.19 may be flagged off.
- [ ] Generated API client from `openapi.json`; zero hand-rolled endpoint types; CI regenerates and fails on drift.
- [ ] Auth: login, paste-key, proactive refresh, 401 recovery, multi-server switching — all covered by integration tests against a live test server.
- [ ] Escalation E2E: push (or poll) → deep link → biometric → approve → server state verified; expiry/raced-resolution handled gracefully.
- [ ] Chat SSE: stream renders all six event types; kill-network-mid-stream reconciles without dupes; stop button cancels via WS.
- [ ] Realtime: WS connects with a fresh ticket on every reconnect; key never appears in a URL; frame/event types generated from `events.json`.
- [ ] All destructive actions confirm; all show-once values use the show-once modal.
- [ ] Security checklist §10 audited line-by-line.
- [ ] Dark/light themes, dynamic type, screen-reader labels verified on both platforms.
- [ ] Crash-free demo of milestones M1–M5 acceptance gates on physical iPhone + Android.

---

## 13. Deliverables

1. App source in the agos monorepo under `mobile/` (TypeScript, Expo), with README covering setup, codegen, and EAS builds.
2. EAS build profiles (dev/preview/prod) + CI workflow for codegen-drift check, typecheck, lint, unit tests.
3. Store-ready metadata/assets for TestFlight + Play internal track.
4. A short integration doc listing any API gaps/bugs found (we expect some — file them, don't work around silently).

## Related

- [[Mobile App Plan]] — original phase plan (April 2026; auth phase is now largely superseded — `auth/login`/`refresh`/`me` already exist server-side)
- [[Mobile App Research]] — stack rationale
- [[Mobile App Data Flow]] — architecture diagrams
- [[03-device-registration-and-push-relay]] — backend push work (§9 here)
- `crates/agentos-api/openapi.json` — the source-of-truth API contract
- `crates/agentos-api/events.json` — WebSocket frames + event catalog
- `agentos-panel` (separate repo) — React web panel, reference client for the same API

## Revision history

| Date | Change |
|---|---|
| 2026-06-11 | Initial handoff spec. |
| 2026-09-19 | Re-synced against `openapi.json` (177 ops) + router. Fixed: escalation query param (`pending`, was `all`), escalation shape (`metadata.*`, PascalCase risk class, `expires_at` countdown), resolve `remember`. Added: WebSocket realtime (§8), chat stop + attachments + inline approval card, approval Rules segment, workspace grants, channel pairing approvals + channel/connector CRUD, MCP catalog install, skills, providers, agent memory/inbox/avatar settings, per-server MCP grants, notification read/clear-all, file filters, agent-chat operator messages + continue, reference-client pointer. Backend deps (§9) re-verified still unbuilt. |
